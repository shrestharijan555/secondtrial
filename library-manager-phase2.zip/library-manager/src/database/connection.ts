import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection, type SQLiteDBConnection } from '@capacitor-community/sqlite';
import { MIGRATIONS } from './migrations';

const DB_NAME = 'library';
const sqlite = new SQLiteConnection(CapacitorSQLite);
let db: SQLiteDBConnection | null = null;

/** Opens the persistent on-device database and applies pending migrations. Safe to call repeatedly. */
export async function getDb(): Promise<SQLiteDBConnection> {
  if (db) return db;
  if (Capacitor.getPlatform() === 'web') {
    throw new Error('SQLite runs on the Android app only. Build the APK or run on an emulator.');
  }
  const consistent = (await sqlite.checkConnectionsConsistency()).result;
  const exists = (await sqlite.isConnection(DB_NAME, false)).result;
  const conn = consistent && exists
    ? await sqlite.retrieveConnection(DB_NAME, false)
    : await sqlite.createConnection(DB_NAME, false, 'no-encryption', 1, false);
  await conn.open();
  await conn.execute('PRAGMA foreign_keys = ON;', false);
  await migrate(conn);
  db = conn;
  return conn;
}

async function migrate(conn: SQLiteDBConnection) {
  const res = await conn.query('PRAGMA user_version;');
  const current = Number(res.values?.[0]?.user_version ?? 0);
  for (let v = current; v < MIGRATIONS.length; v++) {
    await conn.beginTransaction();
    try {
      await conn.execute(MIGRATIONS[v], false);
      await conn.execute(`PRAGMA user_version = ${v + 1};`, false);
      await conn.commitTransaction();
    } catch (e) {
      await conn.rollbackTransaction();
      throw new Error(`Migration ${v + 1} failed: ${(e as Error).message}`);
    }
  }
}

/** Runs fn inside one atomic transaction; rolls back on any error. */
export async function withTransaction<T>(fn: (c: SQLiteDBConnection) => Promise<T>): Promise<T> {
  const c = await getDb();
  await c.beginTransaction();
  try {
    const out = await fn(c);
    await c.commitTransaction();
    return out;
  } catch (e) {
    await c.rollbackTransaction();
    throw e;
  }
}

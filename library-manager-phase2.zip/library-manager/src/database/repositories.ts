import { getDb, withTransaction } from './connection';
import type { Book, BookInput, BookUpdate, DashboardStats, LoanView, Member, MemberInput, Settings } from '../types';
import { addDays, today } from '../utils/dates';
import { calcFine, overdueDays } from '../utils/fines';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Row = Record<string, any>;
const q = async (sql: string, params: unknown[] = []): Promise<Row[]> =>
  (await (await getDb()).query(sql, params as never[])).values ?? [];

const toBook = (r: Row): Book => ({
  id: r.id, title: r.title, author: r.author, publisher: r.publisher, isbn: r.isbn,
  category: r.category, language: r.language, shelf: r.shelf, coverUri: r.cover_uri,
  totalCopies: r.total_copies, availableCopies: r.available_copies,
  damagedCopies: r.damaged_copies, lostCopies: r.lost_copies,
});
const toMember = (r: Row): Member => ({
  id: r.id, memberCode: r.member_code, name: r.name, phone: r.phone, email: r.email,
  status: r.status, joinedAt: r.joined_at,
});

export const BookRepo = {
  async list(search = ''): Promise<Book[]> {
    const like = `%${search.trim()}%`;
    return (await q(
      `SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? ORDER BY title COLLATE NOCASE`,
      [like, like, like],
    )).map(toBook);
  },
  async add(b: BookInput): Promise<void> {
    if (!b.title.trim() || !b.author.trim()) throw new Error('Title and author are required.');
    if (!Number.isInteger(b.totalCopies) || b.totalCopies < 1) throw new Error('Copies must be at least 1.');
    const c = await getDb();
    try {
      await c.run(
        `INSERT INTO books(title,author,publisher,isbn,category,language,shelf,cover_uri,total_copies,available_copies)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [b.title.trim(), b.author.trim(), b.publisher, b.isbn || null, b.category, b.language, b.shelf, b.coverUri, b.totalCopies, b.totalCopies],
      );
    } catch (e) {
      if (String(e).includes('UNIQUE')) throw new Error('A book with this ISBN already exists.');
      throw e;
    }
  },
  async update(b: BookUpdate): Promise<void> {
    if (!b.title.trim() || !b.author.trim()) throw new Error('Title and author are required.');
    await withTransaction(async (c) => {
      const cur = ((await c.query('SELECT total_copies t, available_copies a, damaged_copies d, lost_copies l FROM books WHERE id=?', [b.id])).values ?? [])[0] as Row | undefined;
      if (!cur) throw new Error('Book not found.');
      const onLoan = cur.t - cur.a - cur.d - cur.l;
      if (!Number.isInteger(b.totalCopies) || b.totalCopies < onLoan + cur.d + cur.l)
        throw new Error(`Total copies cannot be below ${onLoan + cur.d + cur.l} (copies on loan, damaged or lost).`);
      try {
        await c.run(
          `UPDATE books SET title=?,author=?,publisher=?,isbn=?,category=?,language=?,shelf=?,total_copies=?,available_copies=? WHERE id=?`,
          [b.title.trim(), b.author.trim(), b.publisher, b.isbn || null, b.category, b.language, b.shelf, b.totalCopies, b.totalCopies - onLoan - cur.d - cur.l, b.id], false);
      } catch (e) {
        if (String(e).includes('UNIQUE')) throw new Error('Another book already uses this ISBN.');
        throw e;
      }
    });
  },
  async remove(id: number): Promise<void> {
    const [{ n }] = await q('SELECT COUNT(*) n FROM loans WHERE book_id = ?', [id]);
    if (n > 0) throw new Error('This book has loan history and cannot be deleted.');
    await (await getDb()).run('DELETE FROM books WHERE id = ?', [id]);
  },
};

export const MemberRepo = {
  async list(search = ''): Promise<Member[]> {
    const like = `%${search.trim()}%`;
    return (await q(`SELECT * FROM members WHERE name LIKE ? OR member_code LIKE ? ORDER BY name COLLATE NOCASE`, [like, like])).map(toMember);
  },
  async add(m: MemberInput): Promise<void> {
    if (!m.name.trim()) throw new Error('Name is required.');
    await withTransaction(async (c) => {
      const [{ n }] = ((await c.query('SELECT COALESCE(MAX(id),0)+1 n FROM members')).values ?? []) as Row[];
      await c.run('INSERT INTO members(member_code,name,phone,email) VALUES (?,?,?,?)',
        [`M${String(n).padStart(5, '0')}`, m.name.trim(), m.phone, m.email], false);
    });
  },
  async update(id: number, m: MemberInput): Promise<void> {
    if (!m.name.trim()) throw new Error('Name is required.');
    await (await getDb()).run('UPDATE members SET name=?, phone=?, email=? WHERE id=?', [m.name.trim(), m.phone, m.email, id]);
  },
  async setStatus(id: number, status: Member['status']): Promise<void> {
    await (await getDb()).run('UPDATE members SET status=? WHERE id=?', [status, id]);
  },
  async remove(id: number): Promise<void> {
    const [{ n }] = await q('SELECT COUNT(*) n FROM loans WHERE member_id = ?', [id]);
    if (n > 0) throw new Error('This member has loan history and cannot be deleted.');
    await (await getDb()).run('DELETE FROM members WHERE id = ?', [id]);
  },
};

/** All inventory changes happen inside one transaction with the loan record. */
export const LoanRepo = {
  async issue(bookId: number, memberId: number): Promise<void> {
    const s = await SettingsRepo.get();
    await withTransaction(async (c) => {
      const first = async (sql: string, p: unknown[]) => ((await c.query(sql, p as never[])).values ?? [])[0] as Row | undefined;
      const book = await first('SELECT available_copies a FROM books WHERE id=?', [bookId]);
      const member = await first('SELECT status FROM members WHERE id=?', [memberId]);
      if (!book) throw new Error('Book not found.');
      if (!member) throw new Error('Member not found.');
      if (member.status !== 'active') throw new Error('Member is suspended.');
      if (book.a < 1) throw new Error('No copies available.');
      const open = (await first('SELECT COUNT(*) n FROM loans WHERE member_id=? AND returned_at IS NULL', [memberId]))!.n;
      if (open >= s.maxBooksPerMember) throw new Error(`Member already has ${open} books (limit ${s.maxBooksPerMember}).`);
      const dup = (await first('SELECT COUNT(*) n FROM loans WHERE member_id=? AND book_id=? AND returned_at IS NULL', [memberId, bookId]))!.n;
      if (dup > 0) throw new Error('Member already has this title on loan.');
      await c.run('INSERT INTO loans(book_id,member_id,issued_at,due_at) VALUES (?,?,?,?)',
        [bookId, memberId, today(), addDays(today(), s.loanDays)], false);
      await c.run('UPDATE books SET available_copies = available_copies - 1 WHERE id=?', [bookId], false);
    });
  },
  async renew(loanId: number): Promise<void> {
    const s = await SettingsRepo.get();
    await withTransaction(async (c) => {
      const l = ((await c.query('SELECT due_at, returned_at FROM loans WHERE id=?', [loanId])).values ?? [])[0] as Row | undefined;
      if (!l || l.returned_at) throw new Error('Loan is not active.');
      if (overdueDays(l.due_at) > 0) throw new Error('Overdue loans must be returned first.');
      await c.run('UPDATE loans SET due_at=?, renewals=renewals+1 WHERE id=?', [addDays(l.due_at, s.loanDays), loanId], false);
    });
  },
  /** Returns the fine charged. */
  async giveBack(loanId: number): Promise<number> {
    const s = await SettingsRepo.get();
    return withTransaction(async (c) => {
      const l = ((await c.query('SELECT book_id, due_at, returned_at FROM loans WHERE id=?', [loanId])).values ?? [])[0] as Row | undefined;
      if (!l || l.returned_at) throw new Error('Loan is not active.');
      const fine = calcFine(l.due_at, s.finePerDay);
      await c.run('UPDATE loans SET returned_at=?, fine=? WHERE id=?', [today(), fine, loanId], false);
      await c.run('UPDATE books SET available_copies = available_copies + 1 WHERE id=?', [l.book_id], false);
      return fine;
    });
  },
};

export const SettingsRepo = {
  async get(): Promise<Settings> {
    const m = Object.fromEntries((await q('SELECT key, value FROM settings')).map((r) => [r.key, r.value]));
    return {
      libraryName: m.libraryName ?? 'My Library',
      loanDays: Number(m.loanDays ?? 14),
      maxBooksPerMember: Number(m.maxBooksPerMember ?? 3),
      finePerDay: Number(m.finePerDay ?? 1),
      theme: (m.theme ?? 'system') as Settings['theme'],
    };
  },
  async save(s: Settings): Promise<void> {
    if (s.loanDays < 1 || s.maxBooksPerMember < 1 || s.finePerDay < 0) throw new Error('Enter valid positive numbers.');
    await withTransaction(async (c) => {
      for (const [k, v] of Object.entries(s))
        await c.run('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', [k, String(v)], false);
    });
  },
};

export async function getDashboardStats(): Promise<DashboardStats> {
  const [r] = await q(`SELECT
    (SELECT COUNT(*) FROM books) AS totalBooks,
    (SELECT COALESCE(SUM(available_copies),0) FROM books) AS available,
    (SELECT COUNT(*) FROM loans WHERE returned_at IS NULL) AS borrowed,
    (SELECT COUNT(*) FROM members) AS members,
    (SELECT COUNT(*) FROM loans WHERE returned_at IS NULL AND due_at < ?) AS overdue,
    (SELECT COUNT(*) FROM loans WHERE issued_at = ? OR returned_at = ?) AS tx`, [today(), today(), today()]);
  return { totalBooks: r.totalBooks, availableCopies: r.available, borrowedCopies: r.borrowed, members: r.members, overdue: r.overdue, todayTransactions: r.tx };
}

const toLoan = (r: Row): LoanView => ({
  id: r.id, bookId: r.book_id, memberId: r.member_id, bookTitle: r.title, memberName: r.name, memberCode: r.member_code,
  issuedAt: r.issued_at, dueAt: r.due_at, returnedAt: r.returned_at, renewals: r.renewals, fine: r.fine,
});
const LOAN_SELECT = `SELECT l.*, b.title, m.name, m.member_code FROM loans l
  JOIN books b ON b.id = l.book_id JOIN members m ON m.id = l.member_id`;

export const LoanQuery = {
  active: async () => (await q(`${LOAN_SELECT} WHERE l.returned_at IS NULL ORDER BY l.due_at`)).map(toLoan),
  history: async (limit = 100) => (await q(`${LOAN_SELECT} ORDER BY l.id DESC LIMIT ?`, [limit])).map(toLoan),
  forMember: async (memberId: number) => (await q(`${LOAN_SELECT} WHERE l.member_id = ? ORDER BY l.id DESC`, [memberId])).map(toLoan),
  issuableBooks: async () => (await q('SELECT * FROM books WHERE available_copies > 0 ORDER BY title COLLATE NOCASE')).map(toBook),
  activeMembers: async () => (await q("SELECT * FROM members WHERE status='active' ORDER BY name COLLATE NOCASE")).map(toMember),
};

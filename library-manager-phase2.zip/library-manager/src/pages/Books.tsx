import { useState } from 'react';
import { Pencil, Trash2 } from 'lucide-react';
import { BookRepo } from '../database/repositories';
import { useAsync } from '../hooks/useAsync';
import { Empty, ErrorNote, Page } from '../components/ui';
import type { Book } from '../types';

const blank = { title: '', author: '', isbn: '', publisher: '', category: '', language: '', shelf: '', copies: '1' };
type Form = typeof blank;
const nn = (s: string) => s.trim() || null;

export default function Books() {
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<'title' | 'author' | 'available'>('title');
  const [category, setCategory] = useState('');
  const { data, error, reload } = useAsync(() => BookRepo.list(search), [search]);
  const [form, setForm] = useState<Form>(blank);
  const [editId, setEditId] = useState<number | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const set = (k: keyof Form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });
  const categories = [...new Set((data ?? []).map((b) => b.category).filter(Boolean))] as string[];
  const shown = (data ?? [])
    .filter((b) => !category || b.category === category)
    .sort((a, b) => sort === 'available' ? b.availableCopies - a.availableCopies : String(a[sort]).localeCompare(String(b[sort])));

  async function save() {
    setErr(null);
    const input = { title: form.title, author: form.author, isbn: nn(form.isbn), publisher: nn(form.publisher), category: nn(form.category), language: nn(form.language), shelf: nn(form.shelf), coverUri: null, totalCopies: Number(form.copies) };
    try {
      if (editId) await BookRepo.update({ ...input, id: editId, coverUri: data?.find((b) => b.id === editId)?.coverUri ?? null });
      else await BookRepo.add(input);
      setForm(blank); setEditId(null); await reload();
    } catch (e) { setErr((e as Error).message); }
  }
  function startEdit(b: Book) {
    setEditId(b.id);
    setForm({ title: b.title, author: b.author, isbn: b.isbn ?? '', publisher: b.publisher ?? '', category: b.category ?? '', language: b.language ?? '', shelf: b.shelf ?? '', copies: String(b.totalCopies) });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  async function remove(id: number) {
    setErr(null);
    try { await BookRepo.remove(id); await reload(); } catch (e) { setErr((e as Error).message); }
  }
  return (
    <Page title="Books">
      <ErrorNote msg={err ?? error} />
      <section className="card mb-4 grid gap-2">
        <p className="text-sm font-medium">{editId ? 'Edit book' : 'Add book'}</p>
        <input className="field" placeholder="Title" value={form.title} onChange={set('title')} />
        <input className="field" placeholder="Author" value={form.author} onChange={set('author')} />
        <input className="field" placeholder="Publisher" value={form.publisher} onChange={set('publisher')} />
        <div className="grid grid-cols-2 gap-2">
          <input className="field" placeholder="ISBN" value={form.isbn} onChange={set('isbn')} />
          <input className="field" type="number" min={1} inputMode="numeric" aria-label="Total copies" placeholder="Copies" value={form.copies} onChange={set('copies')} />
          <input className="field" placeholder="Category" value={form.category} onChange={set('category')} />
          <input className="field" placeholder="Language" value={form.language} onChange={set('language')} />
        </div>
        <input className="field" placeholder="Shelf location" value={form.shelf} onChange={set('shelf')} />
        <div className="grid grid-cols-2 gap-2">
          <button className="btn" onClick={save}>{editId ? 'Save changes' : 'Add book'}</button>
          {editId && <button className="btn-ghost" onClick={() => { setEditId(null); setForm(blank); setErr(null); }}>Cancel</button>}
        </div>
      </section>
      <input className="field mb-2" type="search" placeholder="Search title, author or ISBN" value={search} onChange={(e) => setSearch(e.target.value)} />
      <div className="mb-3 grid grid-cols-2 gap-2">
        <select className="field" aria-label="Sort" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)}>
          <option value="title">Sort: title</option><option value="author">Sort: author</option><option value="available">Sort: availability</option>
        </select>
        <select className="field" aria-label="Category" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All categories</option>{categories.map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>
      {shown.length === 0 && <Empty>No books match. Add a title above.</Empty>}
      <ul className="grid gap-2">
        {shown.map((b) => (
          <li key={b.id} className="card flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate font-medium">{b.title}</p>
              <p className="truncate text-sm text-muted">{b.author} · {b.availableCopies}/{b.totalCopies} available{b.shelf ? ` · ${b.shelf}` : ''}</p>
            </div>
            <div className="flex gap-2">
              <button aria-label={`Edit ${b.title}`} className="btn-ghost !px-3" onClick={() => startEdit(b)}><Pencil size={18} /></button>
              <button aria-label={`Delete ${b.title}`} className="btn-ghost !px-3 text-danger" onClick={() => remove(b.id)}><Trash2 size={18} /></button>
            </div>
          </li>
        ))}
      </ul>
    </Page>
  );
}

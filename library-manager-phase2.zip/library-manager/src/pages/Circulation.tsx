import { useState } from 'react';
import { LoanQuery, LoanRepo, SettingsRepo } from '../database/repositories';
import { useAsync } from '../hooks/useAsync';
import { Empty, ErrorNote, Page } from '../components/ui';
import { calcFine, overdueDays } from '../utils/fines';

type Tab = 'active' | 'issue' | 'history';

export default function Circulation() {
  const [tab, setTab] = useState<Tab>('active');
  const [err, setErr] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const active = useAsync(LoanQuery.active);
  const history = useAsync(LoanQuery.history);
  const books = useAsync(LoanQuery.issuableBooks);
  const members = useAsync(LoanQuery.activeMembers);
  const settings = useAsync(SettingsRepo.get);
  const [bookId, setBookId] = useState('');
  const [memberId, setMemberId] = useState('');

  const refresh = () => Promise.all([active.reload(), history.reload(), books.reload()]);
  async function act(fn: () => Promise<string | void>) {
    setErr(null); setInfo(null);
    try { const m = await fn(); if (m) setInfo(m); await refresh(); } catch (e) { setErr((e as Error).message); }
  }
  const perDay = settings.data?.finePerDay ?? 0;

  return (
    <Page title="Circulation">
      <div role="tablist" className="mb-4 grid grid-cols-3 rounded-lg border border-line bg-surface p-1 text-sm">
        {(['active', 'issue', 'history'] as Tab[]).map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}
            className={`min-h-[40px] rounded-md capitalize ${tab === t ? 'bg-brand text-white' : 'text-muted'}`}>
            {t === 'active' ? 'On loan' : t}
          </button>
        ))}
      </div>
      <ErrorNote msg={err ?? active.error} />
      {info && <p className="mb-3 rounded-lg border border-brand/40 bg-brand/10 p-3 text-sm text-brand">{info}</p>}

      {tab === 'issue' && (
        <section className="card grid gap-3">
          <select className="field" value={memberId} onChange={(e) => setMemberId(e.target.value)} aria-label="Member">
            <option value="">Select member</option>
            {members.data?.map((m) => <option key={m.id} value={m.id}>{m.name} ({m.memberCode})</option>)}
          </select>
          <select className="field" value={bookId} onChange={(e) => setBookId(e.target.value)} aria-label="Book">
            <option value="">Select book</option>
            {books.data?.map((b) => <option key={b.id} value={b.id}>{b.title} — {b.availableCopies} left</option>)}
          </select>
          <p className="text-sm text-muted">Due in {settings.data?.loanDays ?? '–'} days from today.</p>
          <button className="btn" disabled={!bookId || !memberId} onClick={() => act(async () => {
            await LoanRepo.issue(Number(bookId), Number(memberId));
            setBookId(''); setMemberId(''); setTab('active'); return 'Book issued.';
          })}>Issue book</button>
        </section>
      )}

      {tab === 'active' && (
        <>
          {active.data?.length === 0 && <Empty>No books are on loan.</Empty>}
          <ul className="grid gap-2">
            {active.data?.map((l) => {
              const late = overdueDays(l.dueAt);
              return (
                <li key={l.id} className="card grid gap-2">
                  <div>
                    <p className="font-medium">{l.bookTitle}</p>
                    <p className="text-sm text-muted">{l.memberName} · due {l.dueAt}</p>
                    {late > 0 && <p className="text-sm text-danger">{late} days overdue · fine {calcFine(l.dueAt, perDay)}</p>}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button className="btn-ghost" disabled={late > 0} onClick={() => act(async () => { await LoanRepo.renew(l.id); return 'Loan renewed.'; })}>Renew</button>
                    <button className="btn" onClick={() => act(async () => {
                      const fine = await LoanRepo.giveBack(l.id);
                      return fine > 0 ? `Returned. Fine charged: ${fine}.` : 'Returned.';
                    })}>Return</button>
                  </div>
                </li>
              );
            })}
          </ul>
        </>
      )}

      {tab === 'history' && (
        <>
          {history.data?.length === 0 && <Empty>No transactions yet.</Empty>}
          <ul className="grid gap-2">
            {history.data?.map((l) => (
              <li key={l.id} className="card text-sm">
                <p className="font-medium">{l.bookTitle}</p>
                <p className="text-muted">{l.memberName} · issued {l.issuedAt} · {l.returnedAt ? `returned ${l.returnedAt}` : `due ${l.dueAt}`}{l.fine > 0 ? ` · fine ${l.fine}` : ''}</p>
              </li>
            ))}
          </ul>
        </>
      )}
    </Page>
  );
}

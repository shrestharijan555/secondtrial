import { useState } from 'react';
import { Pencil, Trash2 } from 'lucide-react';
import { LoanQuery, MemberRepo } from '../database/repositories';
import { useAsync } from '../hooks/useAsync';
import { Empty, ErrorNote, Page } from '../components/ui';
import type { Member } from '../types';

export default function Members() {
  const [search, setSearch] = useState('');
  const { data, error, reload } = useAsync(() => MemberRepo.list(search), [search]);
  const [form, setForm] = useState({ name: '', phone: '', email: '' });
  const [editId, setEditId] = useState<number | null>(null);
  const [openId, setOpenId] = useState<number | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const loans = useAsync(() => (openId ? LoanQuery.forMember(openId) : Promise.resolve([])), [openId]);

  const run = async (fn: () => Promise<void>) => { setErr(null); try { await fn(); await reload(); } catch (e) { setErr((e as Error).message); } };
  const save = () => run(async () => {
    const m = { name: form.name, phone: form.phone.trim() || null, email: form.email.trim() || null };
    if (editId) await MemberRepo.update(editId, m); else await MemberRepo.add(m);
    setForm({ name: '', phone: '', email: '' }); setEditId(null);
  });
  const edit = (m: Member) => { setEditId(m.id); setForm({ name: m.name, phone: m.phone ?? '', email: m.email ?? '' }); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  return (
    <Page title="Members">
      <ErrorNote msg={err ?? error} />
      <section className="card mb-4 grid gap-2">
        <p className="text-sm font-medium">{editId ? 'Edit member' : 'Register member'}</p>
        <input className="field" placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="field" placeholder="Phone (optional)" inputMode="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <input className="field" placeholder="Email (optional)" inputMode="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <div className="grid grid-cols-2 gap-2">
          <button className="btn" onClick={save}>{editId ? 'Save changes' : 'Register member'}</button>
          {editId && <button className="btn-ghost" onClick={() => { setEditId(null); setForm({ name: '', phone: '', email: '' }); }}>Cancel</button>}
        </div>
      </section>
      <input className="field mb-3" type="search" placeholder="Search name or member ID" value={search} onChange={(e) => setSearch(e.target.value)} />
      {data?.length === 0 && <Empty>No members found.</Empty>}
      <ul className="grid gap-2">
        {data?.map((m) => (
          <li key={m.id} className="card grid gap-2">
            <div className="flex items-center justify-between gap-3">
              <button className="min-w-0 text-left" onClick={() => setOpenId(openId === m.id ? null : m.id)}>
                <p className="truncate font-medium">{m.name}</p>
                <p className="text-sm text-muted">{m.memberCode} · {m.status} · joined {m.joinedAt}</p>
              </button>
              <div className="flex gap-2">
                <button aria-label={`Edit ${m.name}`} className="btn-ghost !px-3" onClick={() => edit(m)}><Pencil size={18} /></button>
                <button aria-label={`Remove ${m.name}`} className="btn-ghost !px-3 text-danger" onClick={() => run(() => MemberRepo.remove(m.id))}><Trash2 size={18} /></button>
              </div>
            </div>
            {openId === m.id && (
              <div className="border-t border-line pt-2 text-sm">
                <p className="text-muted">{[m.phone, m.email].filter(Boolean).join(' · ') || 'No contact details'}</p>
                <button className="btn-ghost mt-2 w-full" onClick={() => run(() => MemberRepo.setStatus(m.id, m.status === 'active' ? 'suspended' : 'active'))}>
                  {m.status === 'active' ? 'Suspend membership' : 'Reactivate membership'}
                </button>
                <p className="mb-1 mt-3 font-medium">Borrowing history</p>
                {loans.data?.length === 0 && <p className="text-muted">No loans yet.</p>}
                <ul className="grid gap-1">
                  {loans.data?.map((l) => (
                    <li key={l.id} className="text-muted">{l.bookTitle} · {l.issuedAt} → {l.returnedAt ?? `due ${l.dueAt}`}{l.fine > 0 ? ` · fine ${l.fine}` : ''}</li>
                  ))}
                </ul>
              </div>
            )}
          </li>
        ))}
      </ul>
    </Page>
  );
}

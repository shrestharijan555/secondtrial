import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.librarymanager.app',
  appName: 'Library Manager',
  webDir: 'dist',
  android: { allowMixedContent: false },
  plugins: {
    CapacitorSQLite: { androidIsEncryption: false },
    StatusBar: { overlaysWebView: false },
  },
};
export default config;

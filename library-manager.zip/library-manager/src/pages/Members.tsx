import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import { MemberRepo } from '../database/repositories';
import { useAsync } from '../hooks/useAsync';
import { Empty, ErrorNote, Page } from '../components/ui';

export default function Members() {
  const [search, setSearch] = useState('');
  const { data, error, reload } = useAsync(() => MemberRepo.list(search), [search]);
  const [form, setForm] = useState({ name: '', phone: '', email: '' });
  const [err, setErr] = useState<string | null>(null);

  async function add() {
    setErr(null);
    try {
      await MemberRepo.add({ name: form.name, phone: form.phone.trim() || null, email: form.email.trim() || null });
      setForm({ name: '', phone: '', email: '' }); await reload();
    } catch (e) { setErr((e as Error).message); }
  }
  async function remove(id: number) {
    setErr(null);
    try { await MemberRepo.remove(id); await reload(); } catch (e) { setErr((e as Error).message); }
  }
  return (
    <Page title="Members">
      <ErrorNote msg={err ?? error} />
      <section className="card mb-4 grid gap-2">
        <input className="field" placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="field" placeholder="Phone (optional)" inputMode="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <input className="field" placeholder="Email (optional)" inputMode="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <button className="btn" onClick={add}>Register member</button>
      </section>
      <input className="field mb-3" type="search" placeholder="Search name or member ID" value={search} onChange={(e) => setSearch(e.target.value)} />
      {data?.length === 0 && <Empty>No members yet.</Empty>}
      <ul className="grid gap-2">
        {data?.map((m) => (
          <li key={m.id} className="card flex items-center justify-between gap-3">
            <div className="min-w-0"><p className="truncate font-medium">{m.name}</p><p className="text-sm text-muted">{m.memberCode} · {m.status}</p></div>
            <button aria-label={`Remove ${m.name}`} className="btn-ghost !px-3 text-danger" onClick={() => remove(m.id)}><Trash2 size={18} /></button>
          </li>
        ))}
      </ul>
    </Page>
  );
}

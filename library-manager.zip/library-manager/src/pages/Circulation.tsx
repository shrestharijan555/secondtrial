import { Page, Empty } from '../components/ui';
export default function Circulation() {
  return (
    <Page title="Circulation">
      <Empty>Issue, renew and return screens arrive in Phase 2. The transaction rules (limits, inventory, fines) are already implemented in LoanRepo.</Empty>
    </Page>
  );
}

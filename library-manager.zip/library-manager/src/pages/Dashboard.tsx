import { getDashboardStats } from '../database/repositories';
import { useAsync } from '../hooks/useAsync';
import { ErrorNote, Page } from '../components/ui';

export default function Dashboard() {
  const { data, error } = useAsync(getDashboardStats);
  const tiles: [string, number | undefined][] = [
    ['Total titles', data?.totalBooks], ['Available copies', data?.availableCopies],
    ['Borrowed copies', data?.borrowedCopies], ['Members', data?.members],
    ['Overdue', data?.overdue], ['Transactions today', data?.todayTransactions],
  ];
  return (
    <Page title="Dashboard">
      <ErrorNote msg={error} />
      <div className="grid grid-cols-2 gap-3">
        {tiles.map(([label, n]) => (
          <div key={label} className="card">
            <p className="text-3xl font-semibold tabular-nums">{n ?? '–'}</p>
            <p className="mt-1 text-sm text-muted">{label}</p>
          </div>
        ))}
      </div>
    </Page>
  );
}

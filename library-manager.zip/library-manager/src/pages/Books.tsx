import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import { BookRepo } from '../database/repositories';
import { useAsync } from '../hooks/useAsync';
import { Empty, ErrorNote, Page } from '../components/ui';

export default function Books() {
  const [search, setSearch] = useState('');
  const { data, error, reload } = useAsync(() => BookRepo.list(search), [search]);
  const [form, setForm] = useState({ title: '', author: '', isbn: '', copies: '1' });
  const [err, setErr] = useState<string | null>(null);

  async function add() {
    setErr(null);
    try {
      await BookRepo.add({ title: form.title, author: form.author, isbn: form.isbn.trim() || null, publisher: null, category: null, language: null, shelf: null, coverUri: null, totalCopies: Number(form.copies) });
      setForm({ title: '', author: '', isbn: '', copies: '1' });
      await reload();
    } catch (e) { setErr((e as Error).message); }
  }
  async function remove(id: number) {
    setErr(null);
    try { await BookRepo.remove(id); await reload(); } catch (e) { setErr((e as Error).message); }
  }
  return (
    <Page title="Books">
      <ErrorNote msg={err ?? error} />
      <section className="card mb-4 grid gap-2">
        <input className="field" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input className="field" placeholder="Author" value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} />
        <div className="grid grid-cols-[1fr_90px] gap-2">
          <input className="field" placeholder="ISBN (optional)" value={form.isbn} onChange={(e) => setForm({ ...form, isbn: e.target.value })} />
          <input className="field" type="number" min={1} inputMode="numeric" aria-label="Copies" value={form.copies} onChange={(e) => setForm({ ...form, copies: e.target.value })} />
        </div>
        <button className="btn" onClick={add}>Add book</button>
      </section>
      <input className="field mb-3" type="search" placeholder="Search title, author or ISBN" value={search} onChange={(e) => setSearch(e.target.value)} />
      {data?.length === 0 && <Empty>No books yet. Add your first title above.</Empty>}
      <ul className="grid gap-2">
        {data?.map((b) => (
          <li key={b.id} className="card flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate font-medium">{b.title}</p>
              <p className="truncate text-sm text-muted">{b.author} · {b.availableCopies}/{b.totalCopies} available</p>
            </div>
            <button aria-label={`Delete ${b.title}`} className="btn-ghost !px-3 text-danger" onClick={() => remove(b.id)}><Trash2 size={18} /></button>
          </li>
        ))}
      </ul>
    </Page>
  );
}

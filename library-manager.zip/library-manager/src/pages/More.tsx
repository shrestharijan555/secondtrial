import { useEffect, useState } from 'react';
import { SettingsRepo } from '../database/repositories';
import { applyTheme } from '../hooks/useTheme';
import { ErrorNote, Page } from '../components/ui';
import type { Settings } from '../types';

export default function More() {
  const [s, setS] = useState<Settings | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  useEffect(() => { SettingsRepo.get().then(setS).catch((e: Error) => setErr(e.message)); }, []);
  if (!s) return <Page title="Settings"><ErrorNote msg={err} /></Page>;
  const num = (k: 'loanDays' | 'maxBooksPerMember' | 'finePerDay', label: string) => (
    <label className="grid gap-1 text-sm">{label}
      <input className="field" type="number" min={0} value={s[k]} onChange={(e) => setS({ ...s, [k]: Number(e.target.value) })} />
    </label>
  );
  async function save() {
    setErr(null); setSaved(false);
    try { await SettingsRepo.save(s!); applyTheme(s!.theme); setSaved(true); } catch (e) { setErr((e as Error).message); }
  }
  return (
    <Page title="Settings">
      <ErrorNote msg={err} />
      <section className="card grid gap-3">
        <label className="grid gap-1 text-sm">Library name
          <input className="field" value={s.libraryName} onChange={(e) => setS({ ...s, libraryName: e.target.value })} />
        </label>
        {num('loanDays', 'Loan period (days)')}
        {num('maxBooksPerMember', 'Maximum books per member')}
        {num('finePerDay', 'Fine per overdue day')}
        <label className="grid gap-1 text-sm">Theme
          <select className="field" value={s.theme} onChange={(e) => setS({ ...s, theme: e.target.value as Settings['theme'] })}>
            <option value="system">Match device</option><option value="light">Light</option><option value="dark">Dark</option>
          </select>
        </label>
        <button className="btn" onClick={save}>Save changes</button>
        {saved && <p className="text-sm text-brand">Saved</p>}
      </section>
    </Page>
  );
}

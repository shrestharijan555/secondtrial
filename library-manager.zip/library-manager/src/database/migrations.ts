/** Append-only. Never edit a released migration; add a new one. Index + 1 = schema version. */
export const MIGRATIONS: string[] = [
  `
  CREATE TABLE books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL CHECK (length(trim(title)) > 0),
    author TEXT NOT NULL,
    publisher TEXT, isbn TEXT UNIQUE, category TEXT, language TEXT, shelf TEXT, cover_uri TEXT,
    total_copies INTEGER NOT NULL DEFAULT 1 CHECK (total_copies >= 0),
    available_copies INTEGER NOT NULL DEFAULT 1,
    damaged_copies INTEGER NOT NULL DEFAULT 0 CHECK (damaged_copies >= 0),
    lost_copies INTEGER NOT NULL DEFAULT 0 CHECK (lost_copies >= 0),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (available_copies >= 0 AND available_copies + damaged_copies + lost_copies <= total_copies)
  );
  CREATE TABLE members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL CHECK (length(trim(name)) > 0),
    phone TEXT, email TEXT,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
    joined_at TEXT NOT NULL DEFAULT (date('now'))
  );
  CREATE TABLE loans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE RESTRICT,
    member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE RESTRICT,
    issued_at TEXT NOT NULL, due_at TEXT NOT NULL, returned_at TEXT,
    renewals INTEGER NOT NULL DEFAULT 0,
    fine REAL NOT NULL DEFAULT 0, fine_paid REAL NOT NULL DEFAULT 0
  );
  CREATE INDEX idx_loans_active ON loans(returned_at, due_at);
  CREATE INDEX idx_loans_member ON loans(member_id);
  CREATE INDEX idx_loans_book ON loans(book_id);
  CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  INSERT INTO settings(key, value) VALUES
    ('libraryName','My Library'),('loanDays','14'),('maxBooksPerMember','3'),
    ('finePerDay','1'),('theme','system');
  `,
];

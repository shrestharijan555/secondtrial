import { useEffect } from 'react';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Capacitor } from '@capacitor/core';
import type { Settings } from '../types';

export function applyTheme(pref: Settings['theme']) {
  const dark = pref === 'dark' || (pref === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  if (Capacitor.isNativePlatform()) {
    void StatusBar.setStyle({ style: dark ? Style.Dark : Style.Light }).catch(() => {});
    void StatusBar.setBackgroundColor({ color: dark ? '#0e1418' : '#f4f6f7' }).catch(() => {});
  }
}
export function useTheme(pref: Settings['theme'] | undefined) {
  useEffect(() => { if (pref) applyTheme(pref); }, [pref]);
}

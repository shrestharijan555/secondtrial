export interface Book {
  id: number; title: string; author: string; publisher: string | null; isbn: string | null;
  category: string | null; language: string | null; shelf: string | null; coverUri: string | null;
  totalCopies: number; availableCopies: number; damagedCopies: number; lostCopies: number;
}
export type BookInput = Omit<Book, 'id' | 'availableCopies' | 'damagedCopies' | 'lostCopies'>;
export interface Member {
  id: number; memberCode: string; name: string; phone: string | null; email: string | null;
  status: 'active' | 'suspended'; joinedAt: string;
}
export type MemberInput = Pick<Member, 'name' | 'phone' | 'email'>;
export interface Settings {
  libraryName: string; loanDays: number; maxBooksPerMember: number; finePerDay: number; theme: 'light' | 'dark' | 'system';
}
export interface DashboardStats {
  totalBooks: number; availableCopies: number; borrowedCopies: number; members: number; overdue: number; todayTransactions: number;
}

const pad = (n: number) => String(n).padStart(2, '0');
export const fmt = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const today = () => fmt(new Date());
const parse = (s: string) => { const [y, m, d] = s.split('-').map(Number); return { y, m, d }; };
export function addDays(iso: string, days: number): string {
  const { y, m, d } = parse(iso);
  return fmt(new Date(y, m - 1, d + days));
}
export function diffDays(fromIso: string, toIso: string): number {
  const u = (s: string) => { const { y, m, d } = parse(s); return Date.UTC(y, m - 1, d); };
  return Math.round((u(toIso) - u(fromIso)) / 86_400_000);
}

import { diffDays, today } from './dates';
export const overdueDays = (dueIso: string, onIso = today()) => Math.max(0, diffDays(dueIso, onIso));
export const calcFine = (dueIso: string, perDay: number, onIso = today()) => overdueDays(dueIso, onIso) * perDay;

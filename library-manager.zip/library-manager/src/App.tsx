import { useEffect, useState } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import BottomNav from './components/BottomNav';
import Dashboard from './pages/Dashboard';
import Books from './pages/Books';
import Members from './pages/Members';
import Circulation from './pages/Circulation';
import More from './pages/More';
import { getDb } from './database/connection';
import { SettingsRepo } from './database/repositories';
import { useTheme } from './hooks/useTheme';
import { ErrorNote } from './components/ui';
import type { Settings } from './types';

export default function App() {
  const [ready, setReady] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [theme, setTheme] = useState<Settings['theme']>();
  useTheme(theme);
  useEffect(() => {
    getDb().then(() => SettingsRepo.get()).then((s) => { setTheme(s.theme); setReady(true); }).catch((e: Error) => setErr(e.message));
  }, []);
  if (err) return <div className="p-4"><ErrorNote msg={`Could not open the library database. ${err}`} /></div>;
  if (!ready) return <div className="p-6 text-sm text-muted">Opening library…</div>;
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/books" element={<Books />} />
        <Route path="/members" element={<Members />} />
        <Route path="/circulation" element={<Circulation />} />
        <Route path="/more" element={<More />} />
      </Routes>
      <BottomNav />
    </BrowserRouter>
  );
}

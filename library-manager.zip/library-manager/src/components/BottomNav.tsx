import { NavLink } from 'react-router-dom';
import { BookOpen, ArrowLeftRight, Ellipsis, LayoutDashboard, Users } from 'lucide-react';

const items = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/books', label: 'Books', icon: BookOpen },
  { to: '/members', label: 'Members', icon: Users },
  { to: '/circulation', label: 'Circulation', icon: ArrowLeftRight },
  { to: '/more', label: 'More', icon: Ellipsis },
];
export default function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-10 border-t border-line bg-surface" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
      <ul className="mx-auto grid max-w-3xl grid-cols-5">
        {items.map(({ to, label, icon: Icon }) => (
          <li key={to}>
            <NavLink to={to} end={to === '/'} className={({ isActive }) =>
              `flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[11px] transition-colors ${isActive ? 'text-brand' : 'text-muted'}`}>
              <Icon size={22} aria-hidden />{label}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}

import type { ReactNode } from 'react';
export const Page = ({ title, children }: { title: string; children: ReactNode }) => (
  <main className="mx-auto max-w-3xl px-4 pb-28 pt-4">
    <h1 className="mb-4 text-xl font-semibold">{title}</h1>
    {children}
  </main>
);
export const ErrorNote = ({ msg }: { msg: string | null }) =>
  msg ? <p role="alert" className="mb-3 rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-danger">{msg}</p> : null;
export const Empty = ({ children }: { children: ReactNode }) => <p className="card text-sm text-muted">{children}</p>;

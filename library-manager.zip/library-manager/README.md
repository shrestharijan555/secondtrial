# Library Manager (Android)

Offline-first, single-library management app. React + TypeScript + Vite + Tailwind, packaged with Capacitor, data in on-device SQLite (`@capacitor-community/sqlite`).

## Status

**Phase 1 (this commit): foundation.** Not yet verified by a CI build — see "First run" below.

| Area | State |
|---|---|
| Architecture, design tokens, light/dark theme, bottom nav, safe areas | Done |
| SQLite schema + versioned migrations (foreign keys, CHECK constraints) | Done |
| Books: add, search, delete (guarded) | Basic |
| Members: register (auto IDs), search, delete (guarded) | Basic |
| Circulation rules (issue/renew/return, limits, fines, atomic inventory) | Logic done in `LoanRepo`, **no UI yet** |
| Dashboard | 6 live counters; charts/popular/recent pending |
| Settings | Library name, loan days, max books, fine rate, theme |
| Edit screens, covers, inventory, reports (CSV/PDF), backup/restore, notifications | Phase 2+ |
| CI debug build, tagged release workflow | Written, awaiting first run |

## First run

1. `npm install` and commit the generated `package-lock.json`.
2. `npm run build` (type-checks, then bundles).
3. `npx cap add android` and commit the `android/` folder (CI does this automatically if absent).
4. Push to `main`; download the APK from **Actions → Android debug build → Artifacts**.

SQLite only works on-device, so the web dev server shows a clear error instead of data. Test on an emulator or phone.

## Releases

Push a tag such as `v0.1.0`. Add these repository secrets for a signed APK:
`ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`
(`base64 -w0 release.jks`). Without them the release publishes a debug-signed APK and logs a warning. Never commit keystores.

## Structure

`src/database` (schema, migrations, repositories — no UI imports) · `src/pages` · `src/components` · `src/hooks` · `src/utils` · `src/types` · `src/services` (reserved for backup/export).

## Adding a migration

Append a new SQL string to `MIGRATIONS` in `src/database/migrations.ts`. Never edit existing entries.
